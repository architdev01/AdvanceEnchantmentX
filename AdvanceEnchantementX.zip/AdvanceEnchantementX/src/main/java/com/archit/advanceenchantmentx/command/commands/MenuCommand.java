package com.archit.advanceenchantmentx.command.commands;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.command.SubCommand;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;

public class MenuCommand implements SubCommand {

    private final AdvanceEnchantmentX plugin;

    public MenuCommand(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "menu";
    }

    @Override
    public String getDescription() {
        return "Open the enchanter menu.";
    }

    @Override
    public String getSyntax() {
        return "/aex menu";
    }

    @Override
    public String getPermission() {
        return "aex.use.menu";
    }

    @Override
    public void perform(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return;
        }

        plugin.getGuiManager().openMainMenu(player);
    }

    @Override
    public List<String> getTabCompletion(CommandSender sender, String[] args) {
        return new ArrayList<>();
    }
}
