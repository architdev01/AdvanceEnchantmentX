package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class ExecuteEnchant extends CustomEnchant {

    public ExecuteEnchant() {
        super("Execute", EnchantTarget.WEAPON, EnchantRarity.LEGENDARY, 1);
    }

    @Override
    public void onHit(Player attacker, LivingEntity victim, int level, EntityDamageByEntityEvent event) {
        double threshold = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.Execute.hp-threshold", 0.3);
        double multiplier = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.Execute.damage-multiplier", 1.5);

        if (victim.getHealth() / victim.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue() <= threshold) {
            event.setDamage(event.getDamage() * multiplier);
            attacker.sendMessage(org.bukkit.ChatColor.RED + "EXECUTE! Damage multiplied!");
        }
    }
}
