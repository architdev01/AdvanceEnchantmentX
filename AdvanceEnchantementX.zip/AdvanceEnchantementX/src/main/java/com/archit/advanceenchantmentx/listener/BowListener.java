package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.event.entity.ProjectileHitEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class BowListener implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final EnchantManager enchantManager;

    public BowListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantManager = plugin.getEnchantManager();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBowShoot(EntityShootBowEvent event) {
        if (!(event.getEntity() instanceof Player)) return;
        Player player = (Player) event.getEntity();
        ItemStack bow = event.getBow();
        if (bow == null) return;

        Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(bow);
        enchants.forEach((name, data) -> {
            enchantManager.getEnchant(name).ifPresent(enchant -> {
                if (event.getProjectile() instanceof Arrow) {
                    enchant.onBowShoot(player, (Arrow) event.getProjectile(), data[0], event);
                    enchantManager.addXP(bow, name, 1);
                }
            });
        });
    }

    @EventHandler
    public void onProjectileHit(ProjectileHitEvent event) {
        if (event.getEntity() instanceof Arrow) {
            Arrow arrow = (Arrow) event.getEntity();
            
            // Explosive Arrow
            if (arrow.hasMetadata("AEX_Explosive")) {
                int level = arrow.getMetadata("AEX_Explosive").get(0).asInt();
                double radius = plugin.getConfig().getDouble("enchants.ExplosiveArrow.radius", 2.0) + 
                                (plugin.getConfig().getDouble("enchants.ExplosiveArrow.radius-per-level", 0.5) * (level - 1));
                
                arrow.getWorld().createExplosion(arrow.getLocation(), (float) radius, false, false);
                arrow.remove();
                return;
            }

            // Lightning Arrow
            if (arrow.hasMetadata("AEX_Lightning")) {
                if (event.getHitEntity() != null || event.getHitBlock() != null) {
                    org.bukkit.Location loc = event.getHitEntity() != null ? event.getHitEntity().getLocation() : event.getHitBlock().getLocation();
                    loc.getWorld().strikeLightning(loc);
                    arrow.remove();
                    return;
                }
            }

            // Poison Arrow
            if (arrow.hasMetadata("AEX_Poison")) {
                if (event.getHitEntity() instanceof org.bukkit.entity.LivingEntity) {
                    org.bukkit.entity.LivingEntity target = (org.bukkit.entity.LivingEntity) event.getHitEntity();
                    int level = arrow.getMetadata("AEX_Poison").get(0).asInt();
                    int duration = plugin.getConfig().getInt("enchants.PoisonArrow.duration-ticks", 60);
                    int amplifier = plugin.getConfig().getInt("enchants.PoisonArrow.amplifier-per-level", 1) * level;
                    
                    target.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.POISON, duration, amplifier));
                }
            }
        }
    }
}
