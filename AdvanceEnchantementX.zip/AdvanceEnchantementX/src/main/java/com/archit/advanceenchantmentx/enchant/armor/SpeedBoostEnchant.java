package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class SpeedBoostEnchant extends CustomEnchant {
    public SpeedBoostEnchant() {
        super("SpeedBoost", EnchantTarget.BOOTS, EnchantRarity.COMMON, 2);
    }
}
