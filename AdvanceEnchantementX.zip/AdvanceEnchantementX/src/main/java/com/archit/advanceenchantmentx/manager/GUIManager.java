package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import org.bukkit.Bukkit;
import org.bukkit.ChatColor;
import org.bukkit.Material;
import org.bukkit.inventory.Inventory;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;

import java.util.ArrayList;
import java.util.List;

public class GUIManager {

    private final AdvanceEnchantmentX plugin;

    public GUIManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    public void openMainMenu(org.bukkit.entity.Player player) {
        player.openInventory(createMainMenu());
    }

    public Inventory createMainMenu() {
        org.bukkit.configuration.file.FileConfiguration guiConfig = plugin.getConfigManager().getGUIConfig();
        String title = guiConfig.getString("enchanter.title", "&dEnchanter");
        int size = guiConfig.getInt("enchanter.size", 54);
        Inventory inv = Bukkit.createInventory(null, size, ChatColor.translateAlternateColorCodes('&', title));

        // Fill background
        ItemStack filler = createItem(Material.valueOf(guiConfig.getString("enchanter.fill-item.material", "BLACK_STAINED_GLASS_PANE")), " ");
        for (int i = 0; i < size; i++) {
            inv.setItem(i, filler);
        }

        // Add Borders
        ItemStack border = createItem(Material.valueOf(guiConfig.getString("enchanter.borders.material", "MAGENTA_STAINED_GLASS_PANE")), " ");
        for (int i = 0; i < 9; i++) inv.setItem(i, border); // top
        for (int i = size - 9; i < size; i++) inv.setItem(i, border); // bottom
        for (int i = 0; i < size; i += 9) inv.setItem(i, border); // left
        for (int i = 8; i < size; i += 9) inv.setItem(i, border); // right

        // Add Categories
        addCategory(inv, "weapons");
        addCategory(inv, "tools");
        addCategory(inv, "armor");
        addCategory(inv, "bows");
        addCategory(inv, "special");
        addCategory(inv, "fusion");
        addCategory(inv, "upgrades");
        addCategory(inv, "settings");

        return inv;
    }

    private void addCategory(Inventory inv, String path) {
        org.bukkit.configuration.file.FileConfiguration guiConfig = plugin.getConfigManager().getGUIConfig();
        String fullPath = "enchanter.categories." + path;
        int slot = guiConfig.getInt(fullPath + ".slot");
        Material mat = Material.valueOf(guiConfig.getString(fullPath + ".material", "BARRIER"));
        String name = guiConfig.getString(fullPath + ".name", "&cError");
        List<String> lore = guiConfig.getStringList(fullPath + ".lore");

        inv.setItem(slot, createItem(mat, name, lore));
    }

    private ItemStack createItem(Material mat, String name, List<String> lore) {
        ItemStack item = new ItemStack(mat);
        ItemMeta meta = item.getItemMeta();
        if (meta != null) {
            meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', name));
            List<String> coloredLore = new ArrayList<>();
            for (String line : lore) {
                coloredLore.add(ChatColor.translateAlternateColorCodes('&', line));
            }
            meta.setLore(coloredLore);
            item.setItemMeta(meta);
        }
        return item;
    }

    private ItemStack createItem(Material mat, String name) {
        return createItem(mat, name, new ArrayList<>());
    }

    public void openCategoryMenu(org.bukkit.entity.Player player, String category) {
        org.bukkit.configuration.file.FileConfiguration guiConfig = plugin.getConfigManager().getGUIConfig();
        String catName = guiConfig.getString("enchanter.categories." + category + ".name", "&6&l" + category.toUpperCase());
        int size = 54;
        Inventory inv = Bukkit.createInventory(null, size, ChatColor.translateAlternateColorCodes('&', catName));

        // Fill background
        ItemStack filler = createItem(Material.valueOf(guiConfig.getString("enchanter.fill-item.material", "BLACK_STAINED_GLASS_PANE")), " ");
        for (int i = 0; i < size; i++) {
            inv.setItem(i, filler);
        }

        // Add Borders
        ItemStack border = createItem(Material.valueOf(guiConfig.getString("enchanter.borders.material", "MAGENTA_STAINED_GLASS_PANE")), " ");
        for (int i = 0; i < 9; i++) inv.setItem(i, border); // top
        for (int i = size - 9; i < size; i++) inv.setItem(i, border); // bottom
        for (int i = 0; i < size; i += 9) inv.setItem(i, border); // left
        for (int i = 8; i < size; i += 9) inv.setItem(i, border); // right

        // Add Back Button
        inv.setItem(size - 5, createItem(Material.BARRIER, "&c&lBack to Main Menu"));

        // Match enchants
        int slot = 10;
        for (com.archit.advanceenchantmentx.model.CustomEnchant enchant : plugin.getEnchantManager().getRegisteredEnchants().values()) {
            boolean matches = false;
            if (category.equals("weapons") && enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.WEAPON) matches = true;
            if (category.equals("tools") && enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.PICKAXE) matches = true;
            if (category.equals("armor") && (enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.ARMOR || enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.BOOTS)) matches = true;
            if (category.equals("bows") && enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.BOW) matches = true;
            if (category.equals("special") && (enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.SPECIAL || enchant.getTarget() == com.archit.advanceenchantmentx.enums.EnchantTarget.ALL)) matches = true;

            if (matches) {
                // Adjust slot if it hits right border
                if ((slot + 1) % 9 == 0) slot += 2;
                if (slot > 43) break; // Out of bounds for simple implementation

                List<String> lore = new ArrayList<>();
                lore.add("&7Maximum Level: &e" + enchant.getMaxLevel());
                lore.add("&7Rarity: " + enchant.getRarity().getColor() + enchant.getRarity().name());
                lore.add("");
                lore.add("&eClick to apply/buy this enchant!");

                inv.setItem(slot, createItem(Material.ENCHANTED_BOOK, enchant.getDisplayName(), lore));
                slot++;
            }
        }

        player.openInventory(inv);
    }

    public void openFusionMenu(org.bukkit.entity.Player player) {
        String title = ChatColor.translateAlternateColorCodes('&', "&5&l✦ Enchant Fusion ✦");
        Inventory inv = Bukkit.createInventory(null, 27, title);

        ItemStack filler = createItem(Material.BLACK_STAINED_GLASS_PANE, " ");
        for (int i = 0; i < 27; i++) {
            inv.setItem(i, filler);
        }

        inv.setItem(12, null); // Input 1
        inv.setItem(14, null); // Input 2
        inv.setItem(16, createItem(Material.BARRIER, "&c&lEmpty")); // Result (visual)
        inv.setItem(13, createItem(Material.ANVIL, "&a&lFUSE", java.util.Arrays.asList("&7Place two books in the slots", "&7and click here to fuse!")));

        inv.setItem(22, createItem(Material.BARRIER, "&c&lBack to Main Menu"));

        player.openInventory(inv);
    }
}
