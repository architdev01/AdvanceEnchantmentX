package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.scheduler.BukkitRunnable;

public class BleedEnchant extends CustomEnchant {

    public BleedEnchant() {
        super("Bleed", EnchantTarget.WEAPON, EnchantRarity.UNCOMMON, 3);
    }

    @Override
    public void onHit(Player attacker, LivingEntity victim, int level, EntityDamageByEntityEvent event) {
        int durationTicks = AdvanceEnchantmentX.getInstance().getConfig().getInt("enchants.Bleed.duration-ticks", 60);
        double damagePerTick = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.Bleed.damage-per-tick", 1.0);

        new BukkitRunnable() {
            int ticks = 0;
            @Override
            public void run() {
                if (victim.isDead() || ticks >= durationTicks) {
                    this.cancel();
                    return;
                }
                victim.damage(damagePerTick);
                victim.getWorld().spawnParticle(org.bukkit.Particle.REDSTONE, victim.getLocation().add(0, 1, 0), 5, new org.bukkit.Particle.DustOptions(org.bukkit.Color.RED, 1));
                ticks += 20; // Every second
            }
        }.runTaskTimer(AdvanceEnchantmentX.getInstance(), 20, 20);
    }
}
