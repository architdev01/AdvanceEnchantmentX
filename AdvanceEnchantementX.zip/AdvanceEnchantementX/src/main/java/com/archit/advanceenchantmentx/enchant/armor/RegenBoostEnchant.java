package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class RegenBoostEnchant extends CustomEnchant {
    public RegenBoostEnchant() {
        super("RegenBoost", EnchantTarget.ARMOR, EnchantRarity.LEGENDARY, 3);
    }
}
