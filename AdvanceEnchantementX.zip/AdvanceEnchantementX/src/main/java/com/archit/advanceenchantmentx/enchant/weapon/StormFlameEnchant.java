package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class StormFlameEnchant extends CustomEnchant {

    public StormFlameEnchant() {
        super("StormFlame", EnchantTarget.WEAPON, EnchantRarity.GODLY, 1);
    }

    @Override
    public void onHit(Player attacker, LivingEntity victim, int level, EntityDamageByEntityEvent event) {
        // Lightning and Fire
        victim.getWorld().strikeLightningEffect(victim.getLocation());
        victim.damage(10.0);
        victim.setFireTicks(100);
    }
}
