package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class MeteorStrikeEnchant extends CustomEnchant {
    public MeteorStrikeEnchant() {
        super("MeteorStrike", EnchantTarget.SPECIAL, EnchantRarity.GODLY, 1);
    }
}
