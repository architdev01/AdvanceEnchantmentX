package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

public class DamageReductionEnchant extends CustomEnchant {

    public DamageReductionEnchant() {
        super("DamageReduction", EnchantTarget.ARMOR, EnchantRarity.MYTHIC, 4);
    }

    @Override
    public void onDamaged(Player victim, Entity damager, int level, org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        double baseReduction = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.DamageReduction.reduction-percentage", 5.0);
        double reductionPerLevel = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.DamageReduction.reduction-per-level", 2.0);
        double totalReduction = (baseReduction + (reductionPerLevel * (level - 1))) / 100.0;

        event.setDamage(event.getDamage() * (1.0 - totalReduction));
    }
}
