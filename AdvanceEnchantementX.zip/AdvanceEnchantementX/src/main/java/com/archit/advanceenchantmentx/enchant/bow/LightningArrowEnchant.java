package com.archit.advanceenchantmentx.enchant.bow;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.metadata.FixedMetadataValue;
import com.archit.advanceenchantmentx.AdvanceEnchantmentX;

public class LightningArrowEnchant extends CustomEnchant {

    public LightningArrowEnchant() {
        super("LightningArrow", EnchantTarget.BOW, EnchantRarity.EPIC, 1);
    }

    @Override
    public void onBowShoot(Player player, Arrow arrow, int level, EntityShootBowEvent event) {
        arrow.setMetadata("AEX_Lightning", new FixedMetadataValue(AdvanceEnchantmentX.getInstance(), level));
    }
}
