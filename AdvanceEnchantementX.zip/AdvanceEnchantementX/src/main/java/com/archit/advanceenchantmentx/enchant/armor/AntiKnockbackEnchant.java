package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.util.Vector;
import org.bukkit.Bukkit;

public class AntiKnockbackEnchant extends CustomEnchant {

    public AntiKnockbackEnchant() {
        super("AntiKnockback", EnchantTarget.ARMOR, EnchantRarity.UNCOMMON, 1);
    }

    @Override
    public void onDamaged(Player victim, Entity damager, int level, EntityDamageByEntityEvent event) {
        // Cancel the knockback by resetting velocity shortly after the event
        Bukkit.getScheduler().runTaskLater(com.archit.advanceenchantmentx.AdvanceEnchantmentX.getInstance(), () -> {
            if (victim.isValid()) {
                victim.setVelocity(new Vector(0, victim.getVelocity().getY(), 0));
            }
        }, 1L);
    }
}
