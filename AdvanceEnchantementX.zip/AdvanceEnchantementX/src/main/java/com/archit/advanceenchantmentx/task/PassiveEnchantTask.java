package com.archit.advanceenchantmentx.task;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import org.bukkit.Bukkit;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;
import org.bukkit.scheduler.BukkitRunnable;

import java.util.Map;

public class PassiveEnchantTask extends BukkitRunnable {

    private final AdvanceEnchantmentX plugin;
    private int tickCount = 0;

    public PassiveEnchantTask(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @Override
    public void run() {
        tickCount += 20; // Runs every 20 ticks (1 second)

        for (Player player : Bukkit.getOnlinePlayers()) {
            if (player.isDead() || !player.isValid()) continue;

            int speedLevel = 0;
            int jumpLevel = 0;
            int regenLevel = 0;
            boolean fireAura = false;
            boolean freezeAura = false;
            
            // Check Armor
            ItemStack[] armor = player.getInventory().getArmorContents();
            for (ItemStack item : armor) {
                if (item == null || item.getType().isAir() || !item.hasItemMeta()) continue;
                
                Map<String, Integer[]> enchants = plugin.getEnchantManager().getEnchantsOnItem(item);
                
                if (enchants.containsKey("SpeedBoost")) {
                    speedLevel = Math.max(speedLevel, enchants.get("SpeedBoost")[0]);
                }
                if (enchants.containsKey("JumpBoost")) {
                    jumpLevel = Math.max(jumpLevel, enchants.get("JumpBoost")[0]);
                }
                if (enchants.containsKey("RegenBoost")) {
                    regenLevel = Math.max(regenLevel, enchants.get("RegenBoost")[0]);
                }
                if (enchants.containsKey("FireAura")) {
                    fireAura = true;
                }
                if (enchants.containsKey("FreezeAura")) {
                    freezeAura = true;
                }
            }

            // Apply Speed
            if (speedLevel > 0) {
                player.removePotionEffect(PotionEffectType.SPEED);
                player.addPotionEffect(new PotionEffect(PotionEffectType.SPEED, 60, speedLevel - 1, true, false, false));
            }

            // Apply Jump
            if (jumpLevel > 0) {
                player.removePotionEffect(PotionEffectType.JUMP);
                player.addPotionEffect(new PotionEffect(PotionEffectType.JUMP, 60, jumpLevel - 1, true, false, false));
            }

            // Apply Regen periodically based on tickCount and config
            if (regenLevel > 0) {
                int regenTicks = plugin.getConfig().getInt("enchants.RegenBoost.interval-ticks", 100);
                if (tickCount % regenTicks == 0) {
                    double healAmount = plugin.getConfig().getDouble("enchants.RegenBoost.heal-amount", 1.0) * regenLevel;
                    double newHealth = Math.min(player.getHealth() + healAmount, player.getMaxHealth());
                    player.setHealth(newHealth);
                }
            }

            // Fire Aura / Freeze Aura could search for nearby entities and apply effects
            if (fireAura && tickCount % 40 == 0) { // every 2 seconds
                int radius = plugin.getConfig().getInt("enchants.FireAura.radius", 3);
                int duration = plugin.getConfig().getInt("enchants.FireAura.duration-ticks", 40);
                for (org.bukkit.entity.Entity entity : player.getNearbyEntities(radius, radius, radius)) {
                    if (entity instanceof org.bukkit.entity.LivingEntity && entity != player) {
                        entity.setFireTicks(duration);
                    }
                }
            }
            if (freezeAura && tickCount % 40 == 0) { // every 2 seconds
                int radius = plugin.getConfig().getInt("enchants.FreezeAura.radius", 3);
                int duration = plugin.getConfig().getInt("enchants.FreezeAura.duration-ticks", 40);
                for (org.bukkit.entity.Entity entity : player.getNearbyEntities(radius, radius, radius)) {
                    if (entity instanceof org.bukkit.entity.LivingEntity && entity != player) {
                        ((org.bukkit.entity.LivingEntity) entity).addPotionEffect(new PotionEffect(PotionEffectType.SLOW, duration, 1));
                    }
                }
            }
        }
    }
}
