package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enchant.armor.DamageReductionEnchant;
import com.archit.advanceenchantmentx.enchant.tool.HasteBoostEnchant;
import com.archit.advanceenchantmentx.enchant.tool.Mining3x3Enchant;
import com.archit.advanceenchantmentx.enchant.tool.TelepathyEnchant;
import com.archit.advanceenchantmentx.enchant.weapon.BleedEnchant;
import com.archit.advanceenchantmentx.enchant.weapon.ExecuteEnchant;
import com.archit.advanceenchantmentx.enchant.weapon.LifestealEnchant;
import com.archit.advanceenchantmentx.enchant.bow.ExplosiveArrowEnchant;
import com.archit.advanceenchantmentx.enchant.weapon.LightningStrikeEnchant;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.ChatColor;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Optional;

public class EnchantManager {

    private final AdvanceEnchantmentX plugin;
    private final Map<String, CustomEnchant> registeredEnchants = new HashMap<>();
    private final NamespacedKey enchantKey;

    public EnchantManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantKey = new NamespacedKey(plugin, "custom_enchants");
    }

    public void registerEnchants() {
        register(new LightningStrikeEnchant());
        register(new HasteBoostEnchant());
        register(new TelepathyEnchant());
        register(new DamageReductionEnchant());
        register(new BleedEnchant());
        register(new ExecuteEnchant());
        register(new LifestealEnchant());
        register(new Mining3x3Enchant());
        register(new ExplosiveArrowEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.ThornsPlusEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.AntiKnockbackEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.SpeedBoostEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.JumpBoostEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.NoFallDamageEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.RegenBoostEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.FireAuraEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.FreezeAuraEnchant());
        
        register(new com.archit.advanceenchantmentx.enchant.bow.LightningArrowEnchant());
        register(new com.archit.advanceenchantmentx.enchant.bow.PoisonArrowEnchant());
        register(new com.archit.advanceenchantmentx.enchant.bow.PiercingArrowEnchant());

        register(new com.archit.advanceenchantmentx.enchant.weapon.BlinkEnchant());
        register(new com.archit.advanceenchantmentx.enchant.weapon.ShockwaveEnchant());
        register(new com.archit.advanceenchantmentx.enchant.weapon.MeteorStrikeEnchant());
        register(new com.archit.advanceenchantmentx.enchant.weapon.TimeWarpEnchant());
        register(new com.archit.advanceenchantmentx.enchant.weapon.GodModeEnchant());
        register(new com.archit.advanceenchantmentx.enchant.weapon.StormFlameEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.BerserkModeEnchant());
        register(new com.archit.advanceenchantmentx.enchant.armor.InvisibilityBurstEnchant());
    }

    private void register(CustomEnchant enchant) {
        registeredEnchants.put(enchant.getName().toLowerCase(), enchant);
    }

    public Map<String, CustomEnchant> getRegisteredEnchants() {
        return registeredEnchants;
    }

    public Optional<CustomEnchant> getEnchant(String name) {
        return Optional.ofNullable(registeredEnchants.get(name.toLowerCase()));
    }

    public void applyEnchant(ItemStack item, CustomEnchant enchant, int level) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        PersistentDataContainer container = meta.getPersistentDataContainer();
        String currentEnchants = container.getOrDefault(enchantKey, PersistentDataType.STRING, "");
        
        Map<String, Integer[]> enchantsMap = parseEnchants(currentEnchants);
        enchantsMap.put(enchant.getName(), new Integer[]{level, 0});
        
        container.set(enchantKey, PersistentDataType.STRING, serializeEnchants(enchantsMap));
        updateLore(meta, enchantsMap);
        item.setItemMeta(meta);
    }

    public Map<String, Integer[]> getEnchantsOnItem(ItemStack item) {
        if (item == null || !item.hasItemMeta()) return new HashMap<>();
        String serialized = item.getItemMeta().getPersistentDataContainer().get(enchantKey, PersistentDataType.STRING);
        return parseEnchants(serialized != null ? serialized : "");
    }

    private Map<String, Integer[]> parseEnchants(String data) {
        Map<String, Integer[]> map = new HashMap<>(); // [0] = level, [1] = xp
        if (data == null || data.isEmpty()) return map;
        
        String[] parts = data.split(";");
        for (String part : parts) {
            String[] kv = part.split(":");
            if (kv.length >= 2) {
                try {
                    int level = Integer.parseInt(kv[1]);
                    int xp = kv.length == 3 ? Integer.parseInt(kv[2]) : 0;
                    map.put(kv[0], new Integer[]{level, xp});
                } catch (NumberFormatException ignored) {}
            }
        }
        return map;
    }

    private String serializeEnchants(Map<String, Integer[]> enchants) {
        StringBuilder sb = new StringBuilder();
        enchants.forEach((name, data) -> sb.append(name).append(":").append(data[0]).append(":").append(data[1]).append(";"));
        return sb.toString();
    }

    public void addXP(ItemStack item, String enchantName, int amount) {
        ItemMeta meta = item.getItemMeta();
        if (meta == null) return;

        PersistentDataContainer container = meta.getPersistentDataContainer();
        Map<String, Integer[]> enchants = getEnchantsOnItem(item);
        if (!enchants.containsKey(enchantName)) return;

        Integer[] data = enchants.get(enchantName);
        data[1] += amount;

        // Level up check
        int currentLevel = data[0];
        int requiredXP = getRequiredXP(currentLevel);
        if (data[1] >= requiredXP) {
            getEnchant(enchantName).ifPresent(enchant -> {
                if (currentLevel < enchant.getMaxLevel()) {
                    data[0]++;
                    data[1] -= requiredXP;
                    // message level up?
                }
            });
        }

        container.set(enchantKey, PersistentDataType.STRING, serializeEnchants(enchants));
        updateLore(meta, enchants);
        item.setItemMeta(meta);
    }

    private int getRequiredXP(int level) {
        return level * 100 * 5; // Example scale
    }

    private void updateLore(ItemMeta meta, Map<String, Integer[]> enchants) {
        List<String> lore = meta.hasLore() ? meta.getLore() : new ArrayList<>();
        lore.removeIf(line -> {
            for (CustomEnchant enchant : registeredEnchants.values()) {
                if (ChatColor.stripColor(line).startsWith(ChatColor.stripColor(enchant.getName()))) return true;
            }
            return false;
        });

        List<String> newLore = new ArrayList<>();
        enchants.forEach((name, data) -> {
            getEnchant(name).ifPresent(enchant -> {
                newLore.add(enchant.getDisplayName() + " " + toRoman(data[0]));
            });
        });
        
        newLore.addAll(lore);
        meta.setLore(newLore);
    }

    public ItemStack createEnchantBook(CustomEnchant enchant, int level) {
        ItemStack book = new ItemStack(org.bukkit.Material.ENCHANTED_BOOK);
        ItemMeta meta = book.getItemMeta();
        if (meta == null) return book;

        meta.setDisplayName(ChatColor.translateAlternateColorCodes('&', enchant.getDisplayName() + " &7Book " + toRoman(level)));
        List<String> lore = new ArrayList<>();
        lore.add("&7Rarity: " + enchant.getRarity().getColor() + enchant.getRarity().name());
        lore.add("&7Target: &e" + enchant.getTarget().name());
        lore.add("");
        lore.add("&eDrag and drop on an item to apply!");
        
        List<String> coloredLore = new ArrayList<>();
        for (String line : lore) {
            coloredLore.add(ChatColor.translateAlternateColorCodes('&', line));
        }
        meta.setLore(coloredLore);
        
        // Store enchant info in the book's PDC
        PersistentDataContainer container = meta.getPersistentDataContainer();
        container.set(new NamespacedKey(plugin, "book_enchant"), PersistentDataType.STRING, enchant.getName().toLowerCase());
        container.set(new NamespacedKey(plugin, "book_level"), PersistentDataType.INTEGER, level);
        
        book.setItemMeta(meta);
        return book;
    }

    private String toRoman(int num) {
        String[] romans = {"", "I", "II", "III", "IV", "V", "VI", "VII", "VIII", "IX", "X"};
        return num < romans.length ? romans[num] : String.valueOf(num);
    }
}
