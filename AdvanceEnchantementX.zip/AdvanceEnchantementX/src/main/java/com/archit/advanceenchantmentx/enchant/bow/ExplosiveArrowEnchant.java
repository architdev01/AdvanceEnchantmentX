package com.archit.advanceenchantmentx.enchant.bow;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.metadata.FixedMetadataValue;

public class ExplosiveArrowEnchant extends CustomEnchant {

    public ExplosiveArrowEnchant() {
        super("ExplosiveArrow", EnchantTarget.BOW, EnchantRarity.RARE, 3);
    }

    @Override
    public void onBowShoot(Player player, Arrow arrow, int level, EntityShootBowEvent event) {
        arrow.setMetadata("AEX_Explosive", new FixedMetadataValue(AdvanceEnchantmentX.getInstance(), level));
    }
}
