package com.archit.advanceenchantmentx.command.commands;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.command.SubCommand;
import org.bukkit.command.CommandSender;

import java.util.ArrayList;
import java.util.List;

public class ReloadCommand implements SubCommand {

    private final AdvanceEnchantmentX plugin;

    public ReloadCommand(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "reload";
    }

    @Override
    public String getDescription() {
        return "Reload the plugin configurations.";
    }

    @Override
    public String getSyntax() {
        return "/aex reload";
    }

    @Override
    public String getPermission() {
        return "aex.admin.reload";
    }

    @Override
    public void perform(CommandSender sender, String[] args) {
        plugin.getConfigManager().reloadConfigs();
        sender.sendMessage(plugin.getConfigManager().getMessage("reload-success"));
    }

    @Override
    public List<String> getTabCompletion(CommandSender sender, String[] args) {
        return new ArrayList<>();
    }
}
