package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class LifestealEnchant extends CustomEnchant {

    public LifestealEnchant() {
        super("Lifesteal", EnchantTarget.WEAPON, EnchantRarity.EPIC, 5);
    }

    @Override
    public void onHit(Player attacker, LivingEntity victim, int level, EntityDamageByEntityEvent event) {
        double baseHeal = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.Lifesteal.base-heal", 1.0);
        double healPerLevel = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.Lifesteal.heal-per-level", 0.5);
        double totalHeal = baseHeal + (healPerLevel * (level - 1));

        double newHealth = Math.min(attacker.getHealth() + totalHeal, attacker.getAttribute(org.bukkit.attribute.Attribute.GENERIC_MAX_HEALTH).getValue());
        attacker.setHealth(newHealth);
    }
}
