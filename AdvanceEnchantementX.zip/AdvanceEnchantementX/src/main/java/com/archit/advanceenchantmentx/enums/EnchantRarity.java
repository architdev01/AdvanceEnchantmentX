package com.archit.advanceenchantmentx.enums;

import org.bukkit.ChatColor;

public enum EnchantRarity {
    COMMON("&f", 40.0, 10),
    UNCOMMON("&a", 25.0, 20),
    RARE("&9", 15.0, 30),
    EPIC("&5", 10.0, 40),
    LEGENDARY("&6", 6.0, 50),
    MYTHIC("&d", 3.0, 60),
    GODLY("&4&l", 1.0, 75);

    private final String color;
    private final double defaultChance;
    private final int defaultCost;

    EnchantRarity(String color, double defaultChance, int defaultCost) {
        this.color = color;
        this.defaultChance = defaultChance;
        this.defaultCost = defaultCost;
    }

    public String getColor() {
        return ChatColor.translateAlternateColorCodes('&', color);
    }

    public double getDefaultChance() {
        return defaultChance;
    }

    public int getDefaultCost() {
        return defaultCost;
    }
}
