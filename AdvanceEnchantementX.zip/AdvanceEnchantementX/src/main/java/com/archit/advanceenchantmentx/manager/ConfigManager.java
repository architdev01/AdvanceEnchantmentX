package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import org.bukkit.ChatColor;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;

public class ConfigManager {

    private final AdvanceEnchantmentX plugin;
    private FileConfiguration messagesConfig;
    private File messagesFile;
    private FileConfiguration guiConfig;
    private File guiFile;

    public ConfigManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        loadMessages();
        loadGUI();
    }

    public void loadMessages() {
        messagesFile = new File(plugin.getDataFolder(), "messages.yml");
        if (!messagesFile.exists()) {
            plugin.saveResource("messages.yml", false);
        }
        messagesConfig = YamlConfiguration.loadConfiguration(messagesFile);
    }

    public void loadGUI() {
        guiFile = new File(plugin.getDataFolder(), "gui.yml");
        if (!guiFile.exists()) {
            plugin.saveResource("gui.yml", false);
        }
        guiConfig = YamlConfiguration.loadConfiguration(guiFile);
    }

    public String getMessage(String path) {
        String message = messagesConfig.getString(path);
        if (message == null) return "Message not found: " + path;
        return ChatColor.translateAlternateColorCodes('&', messagesConfig.getString("prefix") + message);
    }

    public String getRawMessage(String path) {
        String message = messagesConfig.getString(path);
        if (message == null) return "Message not found: " + path;
        return ChatColor.translateAlternateColorCodes('&', message);
    }

    public FileConfiguration getGUIConfig() {
        return guiConfig;
    }

    public FileConfiguration getConfig() {
        return plugin.getConfig();
    }

    public void reloadConfigs() {
        plugin.reloadConfig();
        loadMessages();
        loadGUI();
    }
}
