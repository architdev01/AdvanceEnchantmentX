package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class FireAuraEnchant extends CustomEnchant {
    public FireAuraEnchant() {
        super("FireAura", EnchantTarget.ARMOR, EnchantRarity.EPIC, 2);
    }
}
