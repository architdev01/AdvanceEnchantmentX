package com.archit.advanceenchantmentx.enchant.tool;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.GameMode;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.Collection;

public class TelepathyEnchant extends CustomEnchant {

    public TelepathyEnchant() {
        super("Telepathy", EnchantTarget.PICKAXE, EnchantRarity.EPIC, 1);
    }

    @Override
    public void onBlockBreak(Player player, Block block, int level, org.bukkit.event.block.BlockBreakEvent event) {
        if (player.getGameMode() == GameMode.CREATIVE) return;

        Collection<ItemStack> drops = block.getDrops(player.getInventory().getItemInMainHand());
        for (ItemStack drop : drops) {
            if (player.getInventory().firstEmpty() != -1) {
                player.getInventory().addItem(drop);
            } else {
                block.getWorld().dropItemNaturally(block.getLocation(), drop);
            }
        }
        block.setType(org.bukkit.Material.AIR);
    }
}
