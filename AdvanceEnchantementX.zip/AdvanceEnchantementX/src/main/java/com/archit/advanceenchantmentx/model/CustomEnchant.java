package com.archit.advanceenchantmentx.model;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;

public abstract class CustomEnchant {
    
    private final String name;
    private final EnchantTarget target;
    private final EnchantRarity rarity;
    private final int maxLevel;

    public CustomEnchant(String name, EnchantTarget target, EnchantRarity rarity, int maxLevel) {
        this.name = name;
        this.target = target;
        this.rarity = rarity;
        this.maxLevel = maxLevel;
    }

    public String getName() {
        return name;
    }

    public String getDisplayName() {
        return rarity.getColor() + name;
    }

    public EnchantTarget getTarget() {
        return target;
    }

    public EnchantRarity getRarity() {
        return rarity;
    }

    public int getMaxLevel() {
        return maxLevel;
    }

    // Events
    public void onHit(org.bukkit.entity.Player attacker, org.bukkit.entity.LivingEntity victim, int level, org.bukkit.event.entity.EntityDamageByEntityEvent event) {}
    public void onDamaged(org.bukkit.entity.Player victim, org.bukkit.entity.Entity damager, int level, org.bukkit.event.entity.EntityDamageByEntityEvent event) {}
    public void onBlockBreak(org.bukkit.entity.Player player, org.bukkit.block.Block block, int level, org.bukkit.event.block.BlockBreakEvent event) {}
    public void onBowShoot(org.bukkit.entity.Player player, org.bukkit.entity.Arrow arrow, int level, org.bukkit.event.entity.EntityShootBowEvent event) {}
    public void onDash(org.bukkit.entity.Player player, int level) {}
}
