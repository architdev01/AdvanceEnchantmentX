package com.archit.advanceenchantmentx.boss;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.ChatColor;
import org.bukkit.Location;
import org.bukkit.Material;
import org.bukkit.attribute.Attribute;
import org.bukkit.entity.EntityType;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDeathEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.Bukkit;

import java.util.ArrayList;
import java.util.List;
import java.util.Random;

public class BossManager implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final Random random = new Random();

    public BossManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        Bukkit.getPluginManager().registerEvents(this, plugin);
    }

    public void spawnStormBoss(Location loc) {
        LivingEntity boss = (LivingEntity) loc.getWorld().spawnEntity(loc, EntityType.WITHER_SKELETON);
        boss.setCustomName(ChatColor.AQUA + "" + ChatColor.BOLD + "Storm Boss");
        boss.setCustomNameVisible(true);
        boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(1000.0);
        boss.setHealth(1000.0);
        
        // Give equipment
        boss.getEquipment().setHelmet(new ItemStack(Material.DIAMOND_HELMET));
        boss.getEquipment().setItemInMainHand(new ItemStack(Material.TRIDENT));
    }

    public void spawnInfernoBoss(Location loc) {
        LivingEntity boss = (LivingEntity) loc.getWorld().spawnEntity(loc, EntityType.BLAZE);
        boss.setCustomName(ChatColor.DARK_RED + "" + ChatColor.BOLD + "Inferno Boss");
        boss.setCustomNameVisible(true);
        boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(1500.0);
        boss.setHealth(1500.0);
    }

    public void spawnIceTitan(Location loc) {
        LivingEntity boss = (LivingEntity) loc.getWorld().spawnEntity(loc, EntityType.IRON_GOLEM);
        boss.setCustomName(ChatColor.WHITE + "" + ChatColor.BOLD + "Ice Titan");
        boss.setCustomNameVisible(true);
        boss.getAttribute(Attribute.GENERIC_MAX_HEALTH).setBaseValue(2000.0);
        boss.setHealth(2000.0);
    }

    @EventHandler
    public void onBossDeath(EntityDeathEvent event) {
        LivingEntity entity = event.getEntity();
        if (entity.getCustomName() != null) {
            boolean isBoss = false;
            String name = ChatColor.stripColor(entity.getCustomName());

            if (name.equals("Storm Boss") || name.equals("Inferno Boss") || name.equals("Ice Titan")) {
                isBoss = true;
            }

            if (isBoss) {
                // Drop rare enchant book
                List<CustomEnchant> enchants = new ArrayList<>(plugin.getEnchantManager().getRegisteredEnchants().values());
                if (!enchants.isEmpty()) {
                    CustomEnchant randomEnchant = enchants.get(random.nextInt(enchants.size()));
                    ItemStack book = plugin.getEnchantManager().createEnchantBook(randomEnchant, 1);
                    event.getDrops().add(book);
                    
                    Bukkit.broadcastMessage(ChatColor.GOLD + "" + ChatColor.BOLD + "A BOSS HAS BEEN DEFEATED!");
                }
            }
        }
    }
}
