package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class InvisibilityBurstEnchant extends CustomEnchant {
    public InvisibilityBurstEnchant() {
        super("InvisibilityBurst", EnchantTarget.ARMOR, EnchantRarity.MYTHIC, 1);
    }
}
