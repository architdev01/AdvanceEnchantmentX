package com.archit.advanceenchantmentx;

import com.archit.advanceenchantmentx.manager.CommandManager;
import com.archit.advanceenchantmentx.manager.ConfigManager;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import com.archit.advanceenchantmentx.manager.GUIManager;
import com.archit.advanceenchantmentx.manager.ListenerManager;
import org.bukkit.plugin.java.JavaPlugin;

import java.util.logging.Level;

public class AdvanceEnchantmentX extends JavaPlugin {

    private static AdvanceEnchantmentX instance;
    private ConfigManager configManager;
    private EnchantManager enchantManager;
    private GUIManager guiManager;
    private com.archit.advanceenchantmentx.manager.FusionManager fusionManager;
    private com.archit.advanceenchantmentx.boss.BossManager bossManager;
    private com.archit.advanceenchantmentx.manager.StatsManager statsManager;

    @Override
    public void onEnable() {
        instance = this;

        // Initialize Configs
        saveDefaultConfig();
        configManager = new ConfigManager(this);
        
        // Initialize Managers
        enchantManager = new EnchantManager(this);
        guiManager = new GUIManager(this);
        fusionManager = new com.archit.advanceenchantmentx.manager.FusionManager(this);
        bossManager = new com.archit.advanceenchantmentx.boss.BossManager(this);
        statsManager = new com.archit.advanceenchantmentx.manager.StatsManager(this);
        
        // Register Enchants
        enchantManager.registerEnchants();

        // Register Listeners and Commands
        new ListenerManager(this).registerListeners();
        new CommandManager(this).registerCommands();

        // Start Passive Tasks
        new com.archit.advanceenchantmentx.task.PassiveEnchantTask(this).runTaskTimer(this, 20L, 20L);

        getLogger().log(Level.INFO, "AdvanceEnchantmentX has been enabled!");
    }

    @Override
    public void onDisable() {
        getLogger().log(Level.INFO, "AdvanceEnchantmentX has been disabled!");
    }

    public static AdvanceEnchantmentX getInstance() {
        return instance;
    }

    public ConfigManager getConfigManager() {
        return configManager;
    }

    public EnchantManager getEnchantManager() {
        return enchantManager;
    }

    public GUIManager getGuiManager() {
        return guiManager;
    }

    public com.archit.advanceenchantmentx.manager.FusionManager getFusionManager() {
        return fusionManager;
    }

    public com.archit.advanceenchantmentx.boss.BossManager getBossManager() {
        return bossManager;
    }

    public com.archit.advanceenchantmentx.manager.StatsManager getStatsManager() {
        return statsManager;
    }
}
