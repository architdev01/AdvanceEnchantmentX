package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class BlinkEnchant extends CustomEnchant {
    public BlinkEnchant() {
        super("Blink", EnchantTarget.WEAPON, EnchantRarity.MYTHIC, 1);
    }
}
