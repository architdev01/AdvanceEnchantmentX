package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Entity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageEvent;

public class NoFallDamageEnchant extends CustomEnchant {
    public NoFallDamageEnchant() {
        super("NoFallDamage", EnchantTarget.BOOTS, EnchantRarity.EPIC, 1);
    }
    
    // Check damage in CombatListener for FALL damage!
}
