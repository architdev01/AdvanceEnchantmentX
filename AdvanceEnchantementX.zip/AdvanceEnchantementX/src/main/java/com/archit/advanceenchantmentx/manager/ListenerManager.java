package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.listener.BookListener;
import com.archit.advanceenchantmentx.listener.BowListener;
import com.archit.advanceenchantmentx.listener.CombatListener;
import com.archit.advanceenchantmentx.listener.GUIListener;
import com.archit.advanceenchantmentx.listener.MiningListener;
import org.bukkit.Bukkit;

public class ListenerManager {

    private final AdvanceEnchantmentX plugin;

    public ListenerManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    public void registerListeners() {
        Bukkit.getPluginManager().registerEvents(new CombatListener(plugin), plugin);
        Bukkit.getPluginManager().registerEvents(new MiningListener(plugin), plugin);
        Bukkit.getPluginManager().registerEvents(new GUIListener(plugin), plugin);
        Bukkit.getPluginManager().registerEvents(new BookListener(plugin), plugin);
        Bukkit.getPluginManager().registerEvents(new BowListener(plugin), plugin);
        Bukkit.getPluginManager().registerEvents(new com.archit.advanceenchantmentx.listener.AbilityListener(plugin), plugin);
        Bukkit.getPluginManager().registerEvents(new com.archit.advanceenchantmentx.listener.EnvironmentListener(plugin), plugin);
    }
}
