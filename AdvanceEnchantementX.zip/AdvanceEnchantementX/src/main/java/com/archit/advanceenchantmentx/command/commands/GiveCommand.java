package com.archit.advanceenchantmentx.command.commands;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.command.SubCommand;
import org.bukkit.Bukkit;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

public class GiveCommand implements SubCommand {

    private final AdvanceEnchantmentX plugin;

    public GiveCommand(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "give";
    }

    @Override
    public String getDescription() {
        return "Give a custom enchant book to a player.";
    }

    @Override
    public String getSyntax() {
        return "/aex give <player> <enchant> <level>";
    }

    @Override
    public String getPermission() {
        return "aex.admin.give";
    }

    @Override
    public void perform(CommandSender sender, String[] args) {
        if (args.length < 4) {
            sender.sendMessage(plugin.getConfigManager().getMessage("prefix") + "§cUsage: " + getSyntax());
            return;
        }

        Player target = Bukkit.getPlayer(args[1]);
        if (target == null) {
            sender.sendMessage(plugin.getConfigManager().getMessage("player-not-found"));
            return;
        }

        String enchantName = args[2];
        int level;
        try {
            level = Integer.parseInt(args[3]);
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.getConfigManager().getMessage("prefix") + "§cLevel must be a number!");
            return;
        }

        plugin.getEnchantManager().getEnchant(enchantName).ifPresentOrElse(enchant -> {
            target.getInventory().addItem(plugin.getEnchantManager().createEnchantBook(enchant, level));
            sender.sendMessage(plugin.getConfigManager().getMessage("gave-book").replace("%player%", target.getName()));
            target.sendMessage(plugin.getConfigManager().getMessage("book-received").replace("%book%", enchant.getDisplayName() + " " + level));
        }, () -> {
            sender.sendMessage(plugin.getConfigManager().getMessage("enchant-not-found"));
        });
    }

    @Override
    public List<String> getTabCompletion(CommandSender sender, String[] args) {
        if (args.length == 2) {
            return Bukkit.getOnlinePlayers().stream().map(Player::getName).collect(Collectors.toList());
        }
        if (args.length == 3) {
            return new ArrayList<>(plugin.getEnchantManager().getRegisteredEnchants().keySet());
        }
        if (args.length == 4) {
            return List.of("1", "2", "3", "4", "5");
        }
        return new ArrayList<>();
    }
}
