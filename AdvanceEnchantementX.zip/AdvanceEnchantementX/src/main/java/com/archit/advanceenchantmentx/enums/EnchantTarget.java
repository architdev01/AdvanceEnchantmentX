package com.archit.advanceenchantmentx.enums;

import org.bukkit.Material;

public enum EnchantTarget {
    WEAPON,
    PICKAXE,
    ARMOR,
    BOOTS,
    BOW,
    SPECIAL,
    ALL;

    public boolean includes(Material material) {
        String name = material.name();
        switch (this) {
            case WEAPON:
                return name.endsWith("_SWORD") || name.endsWith("_AXE");
            case PICKAXE:
                return name.endsWith("_PICKAXE");
            case ARMOR:
                return name.endsWith("_HELMET") || name.endsWith("_CHESTPLATE") || 
                       name.endsWith("_LEGGINGS") || name.endsWith("_BOOTS");
            case BOOTS:
                return name.endsWith("_BOOTS");
            case BOW:
                return name.equals("BOW") || name.equals("CROSSBOW");
            case SPECIAL:
            case ALL:
                return true;
            default:
                return false;
        }
    }
}
