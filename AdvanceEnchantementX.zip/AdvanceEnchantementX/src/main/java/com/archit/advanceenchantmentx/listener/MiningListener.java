package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import org.bukkit.Material;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.block.BlockBreakEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class MiningListener implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final EnchantManager enchantManager;

    public MiningListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantManager = plugin.getEnchantManager();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onBlockBreak(BlockBreakEvent event) {
        Player player = event.getPlayer();
        ItemStack tool = player.getInventory().getItemInMainHand();
        
        if (tool == null || tool.getType() == Material.AIR) return;

        Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(tool);
        enchants.forEach((name, data) -> {
            enchantManager.getEnchant(name).ifPresent(enchant -> {
                enchant.onBlockBreak(player, event.getBlock(), data[0], event);
                // Also give XP
                enchantManager.addXP(tool, name, 1);
            });
        });
    }
}
