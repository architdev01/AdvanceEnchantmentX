package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.NamespacedKey;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataType;

import java.util.HashMap;
import java.util.Map;
import java.util.Objects;
import java.util.Optional;

public class FusionManager {

    private final AdvanceEnchantmentX plugin;
    private final Map<String, String> fusionRecipes = new HashMap<>();

    public FusionManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        loadRecipes();
    }

    private void loadRecipes() {
        // Enchant1_Enchant2 -> ResultEnchant
        // They must be alphabetical to ensure order doesn't matter (or just register both)
        registerRecipe("fireaura", "lightningstrike", "StormFlame");
    }

    private void registerRecipe(String e1, String e2, String result) {
        fusionRecipes.put(e1 + "_" + e2, result);
        fusionRecipes.put(e2 + "_" + e1, result); // bidirectional
    }

    public ItemStack fuseBooks(ItemStack book1, ItemStack book2) {
        if (book1 == null || book2 == null) return null;
        if (!book1.hasItemMeta() || !book2.hasItemMeta()) return null;

        ItemMeta m1 = book1.getItemMeta();
        ItemMeta m2 = book2.getItemMeta();

        NamespacedKey nameKey = new NamespacedKey(plugin, "book_enchant");
        String en1 = m1.getPersistentDataContainer().get(nameKey, PersistentDataType.STRING);
        String en2 = m2.getPersistentDataContainer().get(nameKey, PersistentDataType.STRING);

        if (en1 != null && en2 != null) {
            // First check if they are the SAME enchant, which means it upgrades the level!
            if (en1.equalsIgnoreCase(en2)) {
                int l1 = m1.getPersistentDataContainer().getOrDefault(new NamespacedKey(plugin, "book_level"), PersistentDataType.INTEGER, 1);
                int l2 = m2.getPersistentDataContainer().getOrDefault(new NamespacedKey(plugin, "book_level"), PersistentDataType.INTEGER, 1);
                
                if (l1 == l2) {
                    Optional<CustomEnchant> optEnchant = plugin.getEnchantManager().getEnchant(en1);
                    if (optEnchant.isPresent()) {
                        CustomEnchant enchant = optEnchant.get();
                        if (l1 < enchant.getMaxLevel()) {
                            return plugin.getEnchantManager().createEnchantBook(enchant, l1 + 1);
                        }
                    }
                }
            } else {
                // Check for recipe
                String recipeKey = en1.toLowerCase() + "_" + en2.toLowerCase();
                if (fusionRecipes.containsKey(recipeKey)) {
                    String resultName = fusionRecipes.get(recipeKey);
                    Optional<CustomEnchant> optResult = plugin.getEnchantManager().getEnchant(resultName);
                    if (optResult.isPresent()) {
                        return plugin.getEnchantManager().createEnchantBook(optResult.get(), 1);
                    }
                }
            }
        }
        return null;
    }
}
