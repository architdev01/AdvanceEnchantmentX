package com.archit.advanceenchantmentx.command.commands;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.command.SubCommand;
import org.bukkit.Material;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;
import org.bukkit.inventory.ItemStack;

import java.util.ArrayList;
import java.util.List;

public class ApplyCommand implements SubCommand {

    private final AdvanceEnchantmentX plugin;

    public ApplyCommand(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @Override
    public String getName() {
        return "apply";
    }

    @Override
    public String getDescription() {
        return "Apply a custom enchant to the item in your hand.";
    }

    @Override
    public String getSyntax() {
        return "/aex apply <enchant> <level>";
    }

    @Override
    public String getPermission() {
        return "aex.admin.apply";
    }

    @Override
    public void perform(CommandSender sender, String[] args) {
        if (!(sender instanceof Player player)) {
            sender.sendMessage("§cOnly players can use this command.");
            return;
        }

        if (args.length < 3) {
            sender.sendMessage(plugin.getConfigManager().getMessage("prefix") + "§cUsage: " + getSyntax());
            return;
        }

        ItemStack item = player.getInventory().getItemInMainHand();
        if (item == null || item.getType() == Material.AIR) {
            sender.sendMessage(plugin.getConfigManager().getMessage("prefix") + "§cYou must hold an item!");
            return;
        }

        String enchantName = args[1];
        int level;
        try {
            level = Integer.parseInt(args[2]);
        } catch (NumberFormatException e) {
            sender.sendMessage(plugin.getConfigManager().getMessage("prefix") + "§cLevel must be a number!");
            return;
        }

        plugin.getEnchantManager().getEnchant(enchantName).ifPresentOrElse(enchant -> {
            plugin.getEnchantManager().applyEnchant(item, enchant, level);
            sender.sendMessage(plugin.getConfigManager().getMessage("prefix") + "§aSuccessfully applied " + enchant.getDisplayName() + " " + level + " §ato your item.");
        }, () -> {
            sender.sendMessage(plugin.getConfigManager().getMessage("enchant-not-found"));
        });
    }

    @Override
    public List<String> getTabCompletion(CommandSender sender, String[] args) {
        if (args.length == 2) {
            return new ArrayList<>(plugin.getEnchantManager().getRegisteredEnchants().keySet());
        }
        if (args.length == 3) {
            return List.of("1", "2", "3", "4", "5");
        }
        return new ArrayList<>();
    }
}
