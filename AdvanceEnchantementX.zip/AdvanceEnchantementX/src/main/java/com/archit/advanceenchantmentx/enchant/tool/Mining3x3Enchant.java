package com.archit.advanceenchantmentx.enchant.tool;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.Material;
import org.bukkit.block.Block;
import org.bukkit.block.BlockFace;
import org.bukkit.entity.Player;
import org.bukkit.event.block.BlockBreakEvent;

import java.util.ArrayList;
import java.util.List;

public class Mining3x3Enchant extends CustomEnchant {

    public Mining3x3Enchant() {
        super("Mining3x3", EnchantTarget.PICKAXE, EnchantRarity.RARE, 1);
    }

    @Override
    public void onBlockBreak(Player player, Block block, int level, BlockBreakEvent event) {
        // Prevent infinite loop
        if (event instanceof DummyBlockBreakEvent) return;

        List<Block> blocks = getNearbyBlocks(player, block, 1);
        for (Block b : blocks) {
            if (b.getType() == Material.AIR || b.getType() == Material.BEDROCK) continue;
            
            // Trigger a dummy event to handle other enchants and block drops
            DummyBlockBreakEvent dummyEvent = new DummyBlockBreakEvent(b, player);
            org.bukkit.Bukkit.getPluginManager().callEvent(dummyEvent);
            if (!dummyEvent.isCancelled()) {
                b.breakNaturally(player.getInventory().getItemInMainHand());
            }
        }
    }

    private List<Block> getNearbyBlocks(Player player, Block block, int radius) {
        List<Block> blocks = new ArrayList<>();
        
        // This is a simplified 3x3 logic. Real logic would depend on the face the player is looking at.
        // For simplicity, we'll use a fixed orientation or look at player's facing.
        
        BlockFace face = getBlockFace(player);
        if (face == BlockFace.UP || face == BlockFace.DOWN) {
            for (int x = -radius; x <= radius; x++) {
                for (int z = -radius; z <= radius; z++) {
                    if (x == 0 && z == 0) continue;
                    blocks.add(block.getRelative(x, 0, z));
                }
            }
        } else if (face == BlockFace.NORTH || face == BlockFace.SOUTH) {
            for (int x = -radius; x <= radius; x++) {
                for (int y = -radius; y <= radius; y++) {
                    if (x == 0 && y == 0) continue;
                    blocks.add(block.getRelative(x, y, 0));
                }
            }
        } else {
            for (int z = -radius; z <= radius; z++) {
                for (int y = -radius; y <= radius; y++) {
                    if (z == 0 && y == 0) continue;
                    blocks.add(block.getRelative(0, y, z));
                }
            }
        }
        
        return blocks;
    }

    private BlockFace getBlockFace(Player player) {
        List<Block> targetBlocks = player.getLastTwoTargetBlocks(null, 5);
        if (targetBlocks.size() < 2) return BlockFace.SELF;
        return targetBlocks.get(1).getFace(targetBlocks.get(0));
    }

    // A dummy event to prevent recursion
    private static class DummyBlockBreakEvent extends BlockBreakEvent {
        public DummyBlockBreakEvent(Block theBlock, Player player) {
            super(theBlock, player);
        }
    }
}
