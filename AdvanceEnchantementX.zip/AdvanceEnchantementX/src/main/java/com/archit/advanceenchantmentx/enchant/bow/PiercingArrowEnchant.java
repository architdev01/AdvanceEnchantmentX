package com.archit.advanceenchantmentx.enchant.bow;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityShootBowEvent;

public class PiercingArrowEnchant extends CustomEnchant {

    public PiercingArrowEnchant() {
        super("PiercingArrow", EnchantTarget.BOW, EnchantRarity.RARE, 1);
    }

    @Override
    public void onBowShoot(Player player, Arrow arrow, int level, EntityShootBowEvent event) {
        arrow.setPierceLevel(1);
    }
}
