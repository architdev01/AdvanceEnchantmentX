package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;

import java.util.Random;

public class LightningStrikeEnchant extends CustomEnchant {

    private final Random random = new Random();

    public LightningStrikeEnchant() {
        super("LightningStrike", EnchantTarget.WEAPON, EnchantRarity.RARE, 3);
    }

    @Override
    public void onHit(Player attacker, LivingEntity victim, int level, org.bukkit.event.entity.EntityDamageByEntityEvent event) {
        double baseChance = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.LightningStrike.base-chance", 5.0);
        double chancePerLevel = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.LightningStrike.chance-per-level", 2.0);
        double totalChance = baseChance + (chancePerLevel * (level - 1));

        if (random.nextDouble() * 100 <= totalChance) {
            victim.getWorld().strikeLightning(victim.getLocation());
            double extraDamage = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.LightningStrike.damage-per-level", 2.0) * level;
            victim.damage(extraDamage, attacker);
        }
    }
}
