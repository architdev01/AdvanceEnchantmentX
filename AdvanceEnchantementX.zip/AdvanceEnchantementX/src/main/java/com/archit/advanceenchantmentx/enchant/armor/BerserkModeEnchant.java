package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class BerserkModeEnchant extends CustomEnchant {
    public BerserkModeEnchant() {
        super("BerserkMode", EnchantTarget.ARMOR, EnchantRarity.GODLY, 1);
    }
}
