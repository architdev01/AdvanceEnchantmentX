package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import org.bukkit.configuration.file.FileConfiguration;
import org.bukkit.configuration.file.YamlConfiguration;

import java.io.File;
import java.io.IOException;
import java.util.UUID;

public class StatsManager {

    private final AdvanceEnchantmentX plugin;
    private File statsFile;
    private FileConfiguration statsConfig;

    public StatsManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        createStatsFile();
    }

    private void createStatsFile() {
        statsFile = new File(plugin.getDataFolder(), "stats.yml");
        if (!statsFile.exists()) {
            statsFile.getParentFile().mkdirs();
            try {
                statsFile.createNewFile();
            } catch (IOException e) {
                e.printStackTrace();
            }
        }
        statsConfig = YamlConfiguration.loadConfiguration(statsFile);
    }

    public void addStat(UUID uuid, String stat, int amount) {
        int current = statsConfig.getInt(uuid.toString() + "." + stat, 0);
        statsConfig.set(uuid.toString() + "." + stat, current + amount);
        saveStats();
    }

    public int getStat(UUID uuid, String stat) {
        return statsConfig.getInt(uuid.toString() + "." + stat, 0);
    }

    private void saveStats() {
        try {
            statsConfig.save(statsFile);
        } catch (IOException e) {
            e.printStackTrace();
        }
    }
}
