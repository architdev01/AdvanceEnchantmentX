package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Entity;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityDamageByEntityEvent;

public class ThornsPlusEnchant extends CustomEnchant {

    public ThornsPlusEnchant() {
        super("ThornsPlus", EnchantTarget.ARMOR, EnchantRarity.RARE, 3);
    }

    @Override
    public void onDamaged(Player victim, Entity damager, int level, EntityDamageByEntityEvent event) {
        if (!(damager instanceof LivingEntity)) return;
        
        double reflectPercentage = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.ThornsPlus.reflect-percentage", 10.0);
        double reflectPerLevel = AdvanceEnchantmentX.getInstance().getConfig().getDouble("enchants.ThornsPlus.reflect-per-level", 5.0);
        double totalReflect = (reflectPercentage + (reflectPerLevel * (level - 1))) / 100.0;

        double damageToReflect = event.getDamage() * totalReflect;
        
        LivingEntity livingDamager = (LivingEntity) damager;
        livingDamager.damage(damageToReflect, victim);
    }
}
