package com.archit.advanceenchantmentx.command;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.command.commands.*;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.command.TabCompleter;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

public class MainCommand implements CommandExecutor, TabCompleter {

    private final AdvanceEnchantmentX plugin;
    private final Map<String, SubCommand> subCommands = new HashMap<>();

    public MainCommand(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        
        registerSubCommand(new GiveCommand(plugin));
        registerSubCommand(new ReloadCommand(plugin));
        registerSubCommand(new ApplyCommand(plugin));
        registerSubCommand(new MenuCommand(plugin));
    }

    private void registerSubCommand(SubCommand subCommand) {
        subCommands.put(subCommand.getName().toLowerCase(), subCommand);
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (args.length == 0) {
            sendHelp(sender);
            return true;
        }

        SubCommand subCommand = subCommands.get(args[0].toLowerCase());
        if (subCommand == null) {
            sendHelp(sender);
            return true;
        }

        if (subCommand.getPermission() != null && !sender.hasPermission(subCommand.getPermission())) {
            sender.sendMessage(plugin.getConfigManager().getMessage("no-permission"));
            return true;
        }

        subCommand.perform(sender, args);
        return true;
    }

    private void sendHelp(CommandSender sender) {
        sender.sendMessage("§8§m      §e§l AdvanceEnchantmentX §8§m      ");
        subCommands.values().forEach(sub -> {
            if (sub.getPermission() == null || sender.hasPermission(sub.getPermission())) {
                sender.sendMessage("§e" + sub.getSyntax() + " §7- " + sub.getDescription());
            }
        });
        sender.sendMessage("§8§m                                     ");
    }

    @Override
    public List<String> onTabComplete(CommandSender sender, Command command, String alias, String[] args) {
        if (args.length == 1) {
            return subCommands.keySet().stream()
                    .filter(name -> name.startsWith(args[0].toLowerCase()))
                    .filter(name -> {
                        SubCommand sub = subCommands.get(name);
                        return sub.getPermission() == null || sender.hasPermission(sub.getPermission());
                    })
                    .collect(Collectors.toList());
        }

        SubCommand subCommand = subCommands.get(args[0].toLowerCase());
        if (subCommand != null) {
            return subCommand.getTabCompletion(sender, args);
        }

        return new ArrayList<>();
    }
}
