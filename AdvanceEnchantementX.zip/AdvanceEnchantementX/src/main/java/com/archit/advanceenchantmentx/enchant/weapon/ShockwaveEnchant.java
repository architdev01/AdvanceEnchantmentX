package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class ShockwaveEnchant extends CustomEnchant {
    public ShockwaveEnchant() {
        super("Shockwave", EnchantTarget.WEAPON, EnchantRarity.LEGENDARY, 1);
    }
}
