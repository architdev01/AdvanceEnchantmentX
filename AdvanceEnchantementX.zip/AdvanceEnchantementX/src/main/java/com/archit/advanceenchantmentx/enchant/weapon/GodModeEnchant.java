package com.archit.advanceenchantmentx.enchant.weapon;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class GodModeEnchant extends CustomEnchant {
    public GodModeEnchant() {
        super("GodMode", EnchantTarget.SPECIAL, EnchantRarity.GODLY, 1);
    }
}
