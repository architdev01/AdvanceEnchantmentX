package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import org.bukkit.entity.LivingEntity;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class CombatListener implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final EnchantManager enchantManager;

    public CombatListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantManager = plugin.getEnchantManager();
    }

    @EventHandler(priority = EventPriority.HIGHEST, ignoreCancelled = true)
    public void onEntityDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            if (event.getEntity() instanceof LivingEntity) {
                LivingEntity victim = (LivingEntity) event.getEntity();
                handleAttackerEnchants(attacker, victim, event);
            }
        }

        if (event.getEntity() instanceof Player) {
            Player victim = (Player) event.getEntity();
            handleVictimEnchants(victim, event.getDamager(), event);
        }
    }

    private void handleAttackerEnchants(Player attacker, LivingEntity victim, EntityDamageByEntityEvent event) {
        ItemStack weapon = attacker.getInventory().getItemInMainHand();
        Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(weapon);

        enchants.forEach((name, data) -> {
            enchantManager.getEnchant(name).ifPresent(enchant -> {
                enchant.onHit(attacker, victim, data[0], event);
            });
        });
    }

    private void handleVictimEnchants(Player victim, org.bukkit.entity.Entity damager, EntityDamageByEntityEvent event) {
        for (ItemStack armor : victim.getInventory().getArmorContents()) {
            if (armor == null) continue;
            Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(armor);
            enchants.forEach((name, data) -> {
                enchantManager.getEnchant(name).ifPresent(enchant -> {
                    enchant.onDamaged(victim, damager, data[0], event);
                });
            });
        }
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onFallDamage(org.bukkit.event.entity.EntityDamageEvent event) {
        if (event.getCause() == org.bukkit.event.entity.EntityDamageEvent.DamageCause.FALL && event.getEntity() instanceof Player) {
            Player player = (Player) event.getEntity();
            ItemStack boots = player.getInventory().getBoots();
            if (boots != null) {
                Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(boots);
                if (enchants.containsKey("NoFallDamage")) {
                    event.setCancelled(true);
                }
            }
        }
    }
}
