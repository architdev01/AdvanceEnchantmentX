package com.archit.advanceenchantmentx.manager;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.command.MainCommand;
import com.archit.advanceenchantmentx.command.EnchanterCommand;

public class CommandManager {

    private final AdvanceEnchantmentX plugin;

    public CommandManager(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    public void registerCommands() {
        plugin.getCommand("advanceenchantmentx").setExecutor(new MainCommand(plugin));
        plugin.getCommand("enchanter").setExecutor(new EnchanterCommand(plugin));
    }
}
