package com.archit.advanceenchantmentx.command;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import org.bukkit.command.Command;
import org.bukkit.command.CommandExecutor;
import org.bukkit.command.CommandSender;
import org.bukkit.entity.Player;

public class EnchanterCommand implements CommandExecutor {

    private final AdvanceEnchantmentX plugin;

    public EnchanterCommand(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @Override
    public boolean onCommand(CommandSender sender, Command command, String label, String[] args) {
        if (!(sender instanceof Player)) {
            sender.sendMessage(plugin.getConfigManager().getMessage("only-players"));
            return true;
        }

        Player player = (Player) sender;
        if (!player.hasPermission("aex.enchanter")) {
            player.sendMessage(plugin.getConfigManager().getMessage("no-permission"));
            return true;
        }

        player.openInventory(plugin.getGuiManager().createMainMenu());
        player.sendMessage(plugin.getConfigManager().getMessage("gui-opened"));
        return true;
    }
}
