package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.EventPriority;
import org.bukkit.event.Listener;
import org.bukkit.event.entity.EntityDamageByEntityEvent;
import org.bukkit.inventory.ItemStack;

import java.util.Map;

public class EnvironmentListener implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final EnchantManager enchantManager;

    public EnvironmentListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantManager = plugin.getEnchantManager();
    }

    @EventHandler(priority = EventPriority.HIGH, ignoreCancelled = true)
    public void onDamage(EntityDamageByEntityEvent event) {
        if (event.getDamager() instanceof Player) {
            Player attacker = (Player) event.getDamager();
            ItemStack weapon = attacker.getInventory().getItemInMainHand();
            if (weapon == null || weapon.getType().isAir()) return;

            Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(weapon);
            
            // Environment boosts based on any custom enchant logic
            // Example: "NetherBoost" or "NightBoost", let's imagine a flat check for TimeWarp or GodMode giving boosts under certain conditions.
            // Or we just add generic flat boosts for demonstration in the premium aspect
            double multiplier = 1.0;
            org.bukkit.World world = attacker.getWorld();
            
            if (world.getEnvironment() == org.bukkit.World.Environment.NETHER) {
                // Check if they have FireAura or fire enchants to give buff
                if (enchants.containsKey("FireAura") || enchants.containsKey("StormFlame")) {
                    multiplier += 0.2; // 20% boost in nether
                }
            }

            if (world.getEnvironment() == org.bukkit.World.Environment.NORMAL && (world.getTime() > 13000 && world.getTime() < 23000)) {
                // Night time
                if (enchants.containsKey("Blink") || enchants.containsKey("InvisibilityBurst")) {
                    multiplier += 0.15; // 15% assassin boost at night
                }
            }

            if (attacker.getLocation().getBlock().isLiquid()) {
                if (enchants.containsKey("FreezeAura")) {
                    multiplier += 0.3; // 30% freeze boost in water
                }
            }

            event.setDamage(event.getDamage() * multiplier);
        }
    }
}
