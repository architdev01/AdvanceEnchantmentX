package com.archit.advanceenchantmentx.enchant.bow;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.entity.Arrow;
import org.bukkit.entity.Player;
import org.bukkit.event.entity.EntityShootBowEvent;
import org.bukkit.metadata.FixedMetadataValue;
import com.archit.advanceenchantmentx.AdvanceEnchantmentX;

public class PoisonArrowEnchant extends CustomEnchant {

    public PoisonArrowEnchant() {
        super("PoisonArrow", EnchantTarget.BOW, EnchantRarity.UNCOMMON, 3);
    }

    @Override
    public void onBowShoot(Player player, Arrow arrow, int level, EntityShootBowEvent event) {
        arrow.setMetadata("AEX_Poison", new FixedMetadataValue(AdvanceEnchantmentX.getInstance(), level));
    }
}
