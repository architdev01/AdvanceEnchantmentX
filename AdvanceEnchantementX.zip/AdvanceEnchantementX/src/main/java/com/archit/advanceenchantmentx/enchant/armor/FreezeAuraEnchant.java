package com.archit.advanceenchantmentx.enchant.armor;

import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;

public class FreezeAuraEnchant extends CustomEnchant {
    public FreezeAuraEnchant() {
        super("FreezeAura", EnchantTarget.ARMOR, EnchantRarity.EPIC, 2);
    }
}
