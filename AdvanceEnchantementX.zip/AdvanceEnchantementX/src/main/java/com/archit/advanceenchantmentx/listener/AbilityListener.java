package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.block.Action;
import org.bukkit.event.player.PlayerInteractEvent;
import org.bukkit.event.player.PlayerToggleSneakEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.EquipmentSlot;

import java.util.Map;

public class AbilityListener implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final EnchantManager enchantManager;

    public AbilityListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantManager = plugin.getEnchantManager();
    }

    @EventHandler
    public void onPlayerInteract(PlayerInteractEvent event) {
        if (event.getHand() != EquipmentSlot.HAND) return;
        if (event.getAction() != Action.RIGHT_CLICK_AIR && event.getAction() != Action.RIGHT_CLICK_BLOCK) return;
        
        Player player = event.getPlayer();
        ItemStack item = player.getInventory().getItemInMainHand();
        if (item.getType().isAir()) return;

        Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(item);
        
        // Active Abilities
        if (enchants.containsKey("Blink")) {
            // execute Blink logic
            handleBlink(player);
        }
        if (enchants.containsKey("Shockwave")) {
            // execute Shockwave logic
            handleShockwave(player);
        }
        if (enchants.containsKey("MeteorStrike")) {
             // Handle MeteorStrike
             handleMeteorStrike(player);
        }
    }

    @EventHandler
    public void onPlayerSneak(PlayerToggleSneakEvent event) {
        if (!event.isSneaking()) return;
        Player player = event.getPlayer();
        
        // Check armor or held item
        // e.g., Berserk Mode
        boolean hasBerserk = false;
        boolean hasInvis = false;
        
        for (ItemStack armor : player.getInventory().getArmorContents()) {
            if (armor != null && !armor.getType().isAir()) {
                 Map<String, Integer[]> enchants = enchantManager.getEnchantsOnItem(armor);
                 if (enchants.containsKey("BerserkMode")) hasBerserk = true;
                 if (enchants.containsKey("InvisibilityBurst")) hasInvis = true;
            }
        }
        
        if (hasBerserk) handleBerserk(player);
        if (hasInvis) handleInvis(player);
    }

    private void handleBlink(Player player) {
        // Find line of sight block
        org.bukkit.block.Block target = player.getTargetBlockExact(10);
        if (target != null) {
            org.bukkit.Location loc = target.getLocation();
            loc.setPitch(player.getLocation().getPitch());
            loc.setYaw(player.getLocation().getYaw());
            player.teleport(loc.add(0.5, 1, 0.5));
            player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDERMAN_TELEPORT, 1.0f, 1.0f);
        }
    }

    private void handleShockwave(Player player) {
        for (org.bukkit.entity.Entity entity : player.getNearbyEntities(5, 5, 5)) {
            if (entity instanceof org.bukkit.entity.LivingEntity && entity != player) {
                org.bukkit.util.Vector direction = entity.getLocation().toVector().subtract(player.getLocation().toVector()).normalize().multiply(1.5).setY(0.75);
                entity.setVelocity(direction);
                ((org.bukkit.entity.LivingEntity) entity).damage(5.0, player);
            }
        }
        player.getWorld().spawnParticle(org.bukkit.Particle.EXPLOSION_LARGE, player.getLocation(), 1);
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_DRAGON_FIREBALL_EXPLODE, 1.0f, 1.0f);
    }

    private void handleMeteorStrike(Player player) {
        org.bukkit.block.Block target = player.getTargetBlockExact(30);
        if (target != null) {
            org.bukkit.entity.Fireball fireball = (org.bukkit.entity.Fireball) player.getWorld().spawnEntity(target.getLocation().clone().add(0, 15, 0), org.bukkit.entity.EntityType.FIREBALL);
            fireball.setDirection(new org.bukkit.util.Vector(0, -1, 0));
            fireball.setYield(5.0f);
        }
    }

    private void handleBerserk(Player player) {
        player.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.INCREASE_DAMAGE, 100, 1));
        player.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.SPEED, 100, 1));
        player.playSound(player.getLocation(), org.bukkit.Sound.ENTITY_ENDER_DRAGON_GROWL, 1.0f, 1.0f);
    }

    private void handleInvis(Player player) {
        player.addPotionEffect(new org.bukkit.potion.PotionEffect(org.bukkit.potion.PotionEffectType.INVISIBILITY, 200, 1));
        player.getWorld().spawnParticle(org.bukkit.Particle.CLOUD, player.getLocation(), 20, 0.5, 1, 0.5, 0.1);
    }
}
