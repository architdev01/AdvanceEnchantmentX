package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import org.bukkit.ChatColor;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;

public class GUIListener implements Listener {

    private final AdvanceEnchantmentX plugin;

    public GUIListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getView().getTitle().startsWith(ChatColor.translateAlternateColorCodes('&', "&8&l✦"))) {
            event.setCancelled(true);
            if (event.getCurrentItem() == null) return;
            if (!(event.getWhoClicked() instanceof org.bukkit.entity.Player)) return;

            org.bukkit.entity.Player player = (org.bukkit.entity.Player) event.getWhoClicked();
            
            // Play click sound
            player.playSound(player.getLocation(), org.bukkit.Sound.UI_BUTTON_CLICK, 1.0f, 1.0f);

            int slot = event.getRawSlot();
            
            String title = ChatColor.translateAlternateColorCodes('&', plugin.getConfigManager().getRawMessage("gui.enchanter.title"));
            if (event.getView().getTitle().equals(title)) {
                // Main Menu Handling
                String clickedCategory = getCategoryFromSlot(slot);
                if (clickedCategory != null) {
                    if (clickedCategory.equals("fusion")) {
                        plugin.getGuiManager().openFusionMenu(player);
                    } else if (clickedCategory.equals("upgrades")) {
                        player.sendMessage(ChatColor.YELLOW + "Drag and drop an enchant book onto another enchant book to upgrade!");
                    } else if (clickedCategory.equals("settings")) {
                        player.sendMessage(ChatColor.RED + "Settings coming soon.");
                    } else {
                        plugin.getGuiManager().openCategoryMenu(player, clickedCategory);
                    }
                }
            } else if (event.getView().getTitle().contains("Fusion")) {
                // Let players put items in slots 12 and 14, result comes in 16
                if (slot != 12 && slot != 14 && slot != 16 && slot < 27) {
                    event.setCancelled(true);
                }
                if (event.getCurrentItem() != null && event.getCurrentItem().getType() == org.bukkit.Material.BARRIER && slot == 22) {
                    event.setCancelled(true);
                    player.openInventory(plugin.getGuiManager().createMainMenu());
                } else if (slot == 13) {
                    // Fuse!
                    event.setCancelled(true);
                    org.bukkit.inventory.ItemStack b1 = event.getInventory().getItem(12);
                    org.bukkit.inventory.ItemStack b2 = event.getInventory().getItem(14);
                    org.bukkit.inventory.ItemStack result = plugin.getFusionManager().fuseBooks(b1, b2);
                    if (result != null) {
                        event.getInventory().setItem(16, result);
                        event.getInventory().setItem(12, null);
                        event.getInventory().setItem(14, null);
                        player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_ANVIL_USE, 1.0f, 1.0f);
                        player.sendMessage(ChatColor.GREEN + "Fusion successful!");
                    } else {
                        player.sendMessage(ChatColor.RED + "Invalid combination or same level maxed out!");
                    }
                } else if (slot == 16) {
                    // Taking the result
                    event.setCancelled(false);
                }
            } else {
                // Category Menu Handling
                if (event.getCurrentItem() != null && event.getCurrentItem().getType() == org.bukkit.Material.BARRIER) {
                    player.openInventory(plugin.getGuiManager().createMainMenu());
                }
            }
        }
    }

    private String getCategoryFromSlot(int slot) {
        org.bukkit.configuration.ConfigurationSection categories = plugin.getConfig().getConfigurationSection("gui.enchanter.categories");
        if (categories == null) return null;
        for (String key : categories.getKeys(false)) {
            if (plugin.getConfig().getInt("gui.enchanter.categories." + key + ".slot") == slot) {
                return key;
            }
        }
        return null;
    }
}
