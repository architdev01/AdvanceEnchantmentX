package com.archit.advanceenchantmentx.enchant.tool;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.enums.EnchantRarity;
import com.archit.advanceenchantmentx.enums.EnchantTarget;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.block.Block;
import org.bukkit.entity.Player;
import org.bukkit.potion.PotionEffect;
import org.bukkit.potion.PotionEffectType;

public class HasteBoostEnchant extends CustomEnchant {

    public HasteBoostEnchant() {
        super("HasteBoost", EnchantTarget.PICKAXE, EnchantRarity.COMMON, 3);
    }

    @Override
    public void onBlockBreak(Player player, Block block, int level, org.bukkit.event.block.BlockBreakEvent event) {
        int duration = AdvanceEnchantmentX.getInstance().getConfig().getInt("enchants.HasteBoost.duration-seconds", 5) * 20;
        player.addPotionEffect(new PotionEffect(PotionEffectType.FAST_DIGGING, duration, level - 1));
    }
}
