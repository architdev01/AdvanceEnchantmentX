package com.archit.advanceenchantmentx.listener;

import com.archit.advanceenchantmentx.AdvanceEnchantmentX;
import com.archit.advanceenchantmentx.manager.EnchantManager;
import com.archit.advanceenchantmentx.model.CustomEnchant;
import org.bukkit.Material;
import org.bukkit.NamespacedKey;
import org.bukkit.entity.Player;
import org.bukkit.event.EventHandler;
import org.bukkit.event.Listener;
import org.bukkit.event.inventory.InventoryClickEvent;
import org.bukkit.inventory.ItemStack;
import org.bukkit.inventory.meta.ItemMeta;
import org.bukkit.persistence.PersistentDataContainer;
import org.bukkit.persistence.PersistentDataType;

public class BookListener implements Listener {

    private final AdvanceEnchantmentX plugin;
    private final EnchantManager enchantManager;

    public BookListener(AdvanceEnchantmentX plugin) {
        this.plugin = plugin;
        this.enchantManager = plugin.getEnchantManager();
    }

    @EventHandler
    public void onInventoryClick(InventoryClickEvent event) {
        if (event.getCursor() == null || event.getCurrentItem() == null) return;
        ItemStack cursor = event.getCursor();
        ItemStack current = event.getCurrentItem();

        if (cursor.getType() != Material.ENCHANTED_BOOK) return;
        if (current.getType() == Material.AIR) return;

        ItemMeta bookMeta = cursor.getItemMeta();
        if (bookMeta == null) return;

        PersistentDataContainer bookContainer = bookMeta.getPersistentDataContainer();
        NamespacedKey enchantKey = new NamespacedKey(plugin, "book_enchant");
        NamespacedKey levelKey = new NamespacedKey(plugin, "book_level");

        if (!bookContainer.has(enchantKey, PersistentDataType.STRING)) return;

        String enchantName = bookContainer.get(enchantKey, PersistentDataType.STRING);
        int level = bookContainer.getOrDefault(levelKey, PersistentDataType.INTEGER, 1);

        enchantManager.getEnchant(enchantName).ifPresent(enchant -> {
            if (enchant.getTarget().includes(current.getType())) {
                event.setCancelled(true);
                
                // Get player
                Player player = (Player) event.getWhoClicked();
                
                // Max enchants check
                int maxEnchants = plugin.getConfig().getInt("settings.max-enchants", 5);
                if (enchantManager.getEnchantsOnItem(current).size() >= maxEnchants && !enchantManager.getEnchantsOnItem(current).containsKey(enchant.getName())) {
                    player.sendMessage(plugin.getConfigManager().getMessage("enchant-failed"));
                    return;
                }

                enchantManager.applyEnchant(current, enchant, level);
                event.setCursor(new ItemStack(Material.AIR));
                player.sendMessage(plugin.getConfigManager().getMessage("enchant-success").replace("%enchant%", enchant.getDisplayName()));
                
                // Play sound
                player.playSound(player.getLocation(), org.bukkit.Sound.BLOCK_ENCHANTMENT_TABLE_USE, 1.0f, 1.0f);
            } else {
                event.getWhoClicked().sendMessage(plugin.getConfigManager().getMessage("item-invalid"));
            }
        });
    }
}
